---
name: retencion-contratos
description: Calcula probabilidad de renovar, refinanciar y abandono (churn) por contrato a partir de un Excel de contratos, aplicando el scorecard v4 entrenado con historico 2024-2025. Usar cuando el usuario suba un Excel de contratos y pida churn, riesgo de abandono o probabilidad de renovacion/refinanciamiento.
---

# Retención de contratos (scorecard v4)

Herramienta de priorización. Aplica coeficientes ya entrenados; NO reentrena.

## Archivos
- `assets/scorecard_v4_2025-08-31.xlsx` — coeficientes (hojas: tabla_coeficientes, interceptos, resumen). Si falta, pedirle al usuario que lo adjunte.
- `scripts/score_contratos.py` — script de cálculo.

## Procedimiento
1. Identificar el Excel de contratos del usuario (hoja `data` o la primera hoja).
2. Ejecutar, sin modificar el script:
   `python scripts/score_contratos.py assets/scorecard_v4_2025-08-31.xlsx <archivo_usuario.xlsx> resultado_churn.xlsx`
3. Si responde "Faltan columnas", decir cuáles y NO calcular nada.
4. Entregar `resultado_churn.xlsx` y resumir en el chat: total de contratos, churn esperado del lote, distribución por `grado_churn_relativo` y los 10 contratos con mayor `prob_abandono`.

## Reglas
- Calcular siempre con código, nunca estimar a ojo. Mismo archivo = mismo resultado.
- No mostrar datos personales en el chat: solo contrato y resultados.
- No inventar pesos ni reglas.

## Aclaraciones obligatorias en cada respuesta
- Son estimaciones históricas (contratos 2024-2025, sin validación en 2026). Sirven para ordenar clientes, no para decidir uno solo (AUC ≈ 0.67).
- El grado es relativo al historial: "Bajo" no significa riesgo bajo (aún abandona ~56%).
- `prob_refinanciar` solo aplica a Finance y Leasing; en Credit es "no aplica".
- "Abandono" = no renovó ni refinanció en la base histórica (incluye cierres normales).
- `variables_sin_dato` > 0 indica valores que el scorecard no conoce; la estimación es menos confiable.

## Mantenimiento
Al reentrenar, reemplazar el Excel de `assets/` (guardar la versión anterior con fecha) y actualizar el nombre en el paso 2.
