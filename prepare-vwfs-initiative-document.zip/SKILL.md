---
name: prepare-vwfs-initiative-document
description: Prepara el contenido estructurado y validado del Formato de Iniciativa VWFS a partir de un discovery confirmado. Mapea toda la información a los campos de la plantilla oficial y evita generar documentos genéricos o reconstruir visualmente la plantilla.
---

# Propósito
Transformar un discovery confirmado en un conjunto completo y consistente de campos listos para poblar la plantilla oficial `VWFS AI Opportunity Discovery Template`.

Esta skill NO debe crear un documento alternativo, simplificado o genérico. Su función principal es preparar el contenido estructurado que debe insertarse en la plantilla corporativa oficial.

# Cuándo usar esta skill
Usar únicamente después de que:
1. El discovery esté completo o suficientemente avanzado.
2. La iniciativa haya sido preclasificada.
3. El usuario haya confirmado explícitamente el resumen final.

No usar antes de la confirmación.

# Fuentes obligatorias
Consultar:
- `2_VWFS_AI_Opportunity_Discovery_Template`
- `4_Initiative_Template_Guidelines`
- La conversación completa del discovery confirmado
- La clasificación final o preliminar resultante de `classify-vwfs-initiative`

# Regla principal
No reconstruyas visualmente la plantilla desde cero.

Si el entorno permite poblar directamente la plantilla oficial, utiliza esa plantilla como base.

Si el entorno NO permite editar directamente la plantilla, devuelve el mapeo estructurado completo de campos para que otro mecanismo, como Power Automate, pueda poblarla.

Nunca sustituyas la plantilla oficial por:
- un Word genérico;
- un resumen;
- una lista de viñetas;
- una plantilla vacía;
- un documento con diseño alternativo.

# Mapeo obligatorio
Recorre toda la conversación y completa, cuando exista información confirmada:

## Portada
- nombre_iniciativa
- area_solicitante
- solicitante_contacto
- sponsor
- lider_negocio
- fecha_discovery

## 1. Resumen ejecutivo
- resumen_ejecutivo

## 2. Objetivo / Para qué
- objetivo_iniciativa

## 3. Problema actual
- situacion_actual
- dolor_ineficiencia
- consecuencias_actuales
- riesgo_no_actuar

## 4. Proceso actual — AS-IS
- as_is_flujo
- as_is_actores
- as_is_entradas
- as_is_salidas
- as_is_frecuencia_volumen
- as_is_duracion

## 5. Proceso futuro — TO-BE
- to_be_vision
- to_be_cambios
- to_be_participacion_humana
- to_be_resultado
- to_be_excepciones

## 6. Alcance
- companias
- productos
- tipo_cliente
- marcas

## 7. Impacto esperado y KPIs
- beneficios_cualitativos
- beneficios_cuantitativos
- usuarios_beneficiados
- kpis

Cada KPI debe incluir:
- nombre_kpi
- impacto_porcentaje
- justificacion
- area

## 8. Usuarios y áreas involucradas
- usuarios_principales
- area_propietaria
- areas_involucradas
- terceros_proveedores

## 9. Sistemas, datos y dependencias
- sistemas_herramientas
- datos_involucrados
- integraciones_conocidas
- dependencias
- restricciones_riesgos

## 10. Evaluación inicial y preclasificación
- potencial_automatizacion
- posible_uso_ia
- posible_uso_agente
- alternativa_sin_ia
- complejidad_percibida
- carril
- justificacion_carril

## 11. Pendientes y siguientes pasos
- pendientes
- siguiente_paso_recomendado
- informacion_no_disponible
- observaciones_finales

Cada pendiente debe incluir:
- numero
- pendiente
- responsable_sugerido
- momento

# Reglas de contenido
- Usa únicamente información confirmada durante el discovery.
- No inventes datos para completar campos.
- Si un dato no fue confirmado, déjalo vacío.
- Usa `No aplica` solo cuando el usuario lo haya indicado explícitamente.
- No inventes KPIs ni porcentajes.
- No inventes personas, responsables, enlaces, fechas, sistemas o integraciones.
- Mantén consistencia entre Problema → Objetivo → AS-IS → TO-BE → Alcance → Impacto → Dependencias → Carril → Siguiente paso.
- Marca un solo carril.
- La preclasificación no equivale a aprobación técnica.

# Regla de placeholders
Todo placeholder de la plantilla debe reemplazarse si la información correspondiente fue obtenida.

Si un campo no tiene información:
- conservar el campo;
- dejarlo vacío;
- registrar como pendiente solo si es importante para continuar.

# Salida preferida
Devuelve un objeto estructurado con todos los campos anteriores, aunque algunos estén vacíos.

Formato recomendado:

```json
{
  "nombre_iniciativa": "",
  "area_solicitante": "",
  "solicitante_contacto": "",
  "sponsor": "",
  "lider_negocio": "",
  "fecha_discovery": "",
  "resumen_ejecutivo": "",
  "objetivo_iniciativa": "",
  "situacion_actual": "",
  "dolor_ineficiencia": "",
  "consecuencias_actuales": "",
  "riesgo_no_actuar": "",
  "as_is_flujo": "",
  "as_is_actores": "",
  "as_is_entradas": "",
  "as_is_salidas": "",
  "as_is_frecuencia_volumen": "",
  "as_is_duracion": "",
  "to_be_vision": "",
  "to_be_cambios": "",
  "to_be_participacion_humana": "",
  "to_be_resultado": "",
  "to_be_excepciones": "",
  "companias": [],
  "productos": [],
  "tipo_cliente": [],
  "marcas": [],
  "beneficios_cualitativos": "",
  "beneficios_cuantitativos": "",
  "usuarios_beneficiados": "",
  "kpis": [],
  "usuarios_principales": "",
  "area_propietaria": "",
  "areas_involucradas": "",
  "terceros_proveedores": "",
  "sistemas_herramientas": "",
  "datos_involucrados": "",
  "integraciones_conocidas": "",
  "dependencias": "",
  "restricciones_riesgos": "",
  "potencial_automatizacion": "",
  "posible_uso_ia": "",
  "posible_uso_agente": "",
  "alternativa_sin_ia": "",
  "complejidad_percibida": "",
  "carril": "",
  "justificacion_carril": "",
  "pendientes": [],
  "siguiente_paso_recomendado": "",
  "informacion_no_disponible": "",
  "observaciones_finales": ""
}
```

# Reglas específicas de siguiente paso por carril

## Carril 1
Indicar autogestión mediante capacidades Self-Service disponibles, recursos de capacitación configurados y apoyo opcional del Champion.

## Carril 2
Indicar acompañamiento del Champion para estructuración, configuración, desarrollo o implementación. Aclarar que el tiempo puede variar según complejidad y carga del Champion.

## Carril 3
Indicar participación de IT/Data, incorporación al backlog correspondiente de VWFS, evaluación y priorización conforme a la metodología corporativa.

El resumen del siguiente paso debe ser ejecutivo. El proceso corporativo completo de 14 etapas se obtiene desde `Classification Guidelines` o desde la skill de clasificación; no inventarlo ni modificarlo.

# Validación final
Antes de devolver la salida, comprobar:
1. Se utilizó toda la conversación confirmada, no solo el último mensaje.
2. Ningún dato confirmado quedó fuera del mapeo.
3. Ningún campo fue inventado.
4. El carril coincide con la clasificación.
5. El siguiente paso coincide con el carril.
6. Los placeholders con información disponible quedaron resueltos.
7. Los campos sin información permanecen vacíos.
8. La salida está lista para poblar la plantilla oficial sin rediseñarla.

Si alguna condición falla, corregir el mapeo antes de devolverlo.
